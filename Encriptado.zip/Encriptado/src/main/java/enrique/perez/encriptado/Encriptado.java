

package enrique.perez.encriptado;


public class Encriptado {

    public static void main(String[] args) {
        Generador contra = new Generador();
        contra.Generador(20);
    }
}
