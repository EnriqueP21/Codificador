package enrique.perez.encriptado;
import java.security.SecureRandom;

public class Generador {
    
    private SecureRandom aleatorio = new SecureRandom();
    
    
    public void Generador(int cantidad){
        int i;
        char cadena []= new char[cantidad];
        for( i=0;i<cantidad;i++){
            cadena[i]= (char)Generador.this.Aleatorio();
        }
        System.out.println(cadena);
        
    }
    
    public int Aleatorio(){
        int aleatorio= this.aleatorio.nextInt(78)  +47;
        return aleatorio;
    }
    
}
